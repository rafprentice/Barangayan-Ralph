public static class Icons
{
    public static string seal; // Add this field to match usage in LoginForm.Designer.cs
    public static string QR;
    public static string Lock;
    public static string Digital;
    public static string Mail;
    public static string Shield;
    public static string Check;
    public static string User;
}